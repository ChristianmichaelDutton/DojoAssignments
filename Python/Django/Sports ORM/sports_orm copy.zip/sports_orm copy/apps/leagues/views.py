from django.shortcuts import render, redirect
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues":League.objects.all(),
		"ball":League.objects.filter(sport="Baseball"),
		"womens":League.objects.filter(name__contains="Womens"),
		"hockey":League.objects.filter(sport__contains="Hockey"),
		"exclude_football":League.objects.exclude(sport__contains="Football"),
		"atlantic":League.objects.filter(name__contains="Atlantic"),
		"teams": Team.objects.filter(location="Dallas"),
		"raptors":Team.objects.filter(team_name__contains="Raptors"),
		"city":Team.objects.filter(location__contains="City"),
		"teams_all":Team.objects.all().order_by('location'),
		"teamsreversed":Team.objects.all().order_by('-team_name'),
		"letter_t":Team.objects.filter(team_name__startswith="T"),
		"cooper": Player.objects.filter(last_name__contains="Cooper"),
		"joshua":Player.objects.filter(first_name__contains="Joshua"),
		"exclude_joshua":Player.objects.exclude(first_name__contains="Joshua").filter(last_name__contains="Cooper"),
		"alexander_or_wyatt":Player.objects.filter(first_name__contains="Alexander")| Player.objects.filter(first_name__contains="Wyatt")
	}
	return render(request, "leagues/index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")
