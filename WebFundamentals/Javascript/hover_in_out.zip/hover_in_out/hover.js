$(document).ready(function(){
  $('#square').hide();
  $('.img1' ).hover(function(){
    $('.square1').show();
  },function(){
    $('.square1').hide();
  });
  $('.img2' ).hover(function(){
    $('.square2').show();
  },function(){
    $('.square2').hide();
  });
  $('.img3' ).hover(function(){
    $('.square3').show();
  },function(){
    $('.square3').hide();
  });
  $('.img4' ).hover(function(){
    $('.square4').show();
  },function(){
    $('.square4').hide();
  });
  $('.img5' ).hover(function(){
    $('.squad1').show();
  },function(){
    $('.squad1').hide();
  });
  $('.img6' ).hover(function(){
    $('.squad2').show();
  },function(){
    $('.squad2').hide();
  });
  $('.img7' ).hover(function(){
    $('.squad3').show();
  },function(){
    $('.squad3').hide();
  });
  $('.img8' ).hover(function(){
    $('.squad4').show();
  },function(){
    $('.squad4').hide();
  });
});
