//This is the first javascript file to load, so it initializes the module
var myAppModule = angular.module("myApp", ["ngRoute"]);

myAppModule.factory("AdventurerFactory", function(){
   //Initialize our list of adventurers
   var adventurers = [
      {name:"Ferrowclaw", team:"Uthmarr Families"},
      {name:"Cougarwrath", team:"The Dark Guild"},
      {name:"Dama", team:""},
      {name:"Ammeriti", team:""}
   ];

   var factory = {};

   //Pass the adventurer list to a controller
   factory.getAdventurers = function(callback){
      callback(adventurers);
   }

   //Add new adventurer to the list
   factory.addAdventurer = function(adventurer){
      adventurer.team = ""; //New adventurers don't belong to a team
      adventurers.push(adventurer);
   }

   //Remove the adventurer from the list
   factory.removeAdventurer = function($index){
      adventurers.splice($index, 1);
   }

   //Set a adventurer's team name
   factory.addAdventurerToTeam = function(data){
      adventurers[data.adventurerIdx].team = data.team;
   }

   //Reset a adventurer's team name to an empty string
   factory.removeAdventurerFromTeam = function($index){
      adventurers[$index].team = "";
   }
   return factory;
})
